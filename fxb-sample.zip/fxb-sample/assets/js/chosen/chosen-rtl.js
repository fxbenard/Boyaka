jQuery(document).ready(function($) {

	// Fix Chosen for RTL
	$('.chosen_select, .chosen_select_nostd, select.country_select, select.state_select, select[name=m]').addClass('chosen-rtl');

});