// https://www.npmjs.com/package/grunt-wp-readme-to-markdown
module.exports = {
          your_target: {
            files: {
              'README.md': 'readme.txt'
            },
          },
        };