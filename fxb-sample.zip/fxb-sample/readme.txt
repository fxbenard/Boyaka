=== FxB Sample ===
Contributors: sebd86
Donate link: http://www.sebastiendumont.com/donation/
Tags: wordpress, plugin, boilerplate
Requires at least: 3.9
Tested up to: 4.0
Stable tag: Trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is where you craft a short, punchy description of your plugin

== Description ==

This is where you can give a much longer description of your plugin that you can use to explain just how it awesome it really is.

== Installation ==

Installing "FxB Sample" can be done either by searching for "FxB Sample" via the "Plugins > Add New" screen in your WordPress dashboard, or by using the following steps:

1. Download the plugin via WordPress.org
1. Upload the ZIP file through the 'Plugins > Add New > Upload' screen in your WordPress dashboard
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= What is the plugin boilerplate for? =

This plugin boilerplate is designed to help you get started with any new WordPress plugin.

== Screenshots ==

1. Your first screenshot. Don't forget to have screenshot-1.png

== Changelog ==

= 1.0 =
* 2014-08-28
* Initial release

== Upgrade Notice ==

= 1.0 =
* 2014-08-28
* Initial release