<?php
/**
 * Plugin Name Ajax Functions
 *
 * @since    1.0.0
 * @author FX Bénard
 * @category Core
 * @package  Plugin Name
 * @license  GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Include your ajax code for your plugin here.

?>
