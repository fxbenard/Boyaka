<?php
/**
 * Plugin Name Page Functions
 *
 * @since    1.0.0
 * @author FX Bénard
 * @category Core
 * @package  Plugin Name/Functions
 * @license  GPL-2.0+
 */

/**
 * Output generator to aid debugging.
 *
 * @since  1.0.0
 * @access public
 * @return void
 */
function generator() {
	echo "\n\n" . '<!-- ' . Fxb_Sample()->name . ' Version -->' . "\n" . '<meta name="generator" content="' . esc_attr( Fxb_Sample()->name ) .' ' . esc_attr( Fxb_Sample()->version ) . '" />' . "\n\n";
} // END generator()

?>
