<?php
/**
 * Help is provided for this plugin on the plugin pages.
 *
 * @since    1.0.0
 * @author FX Bénard
 * @category Admin
 * @package  Plugin Name
 * @license  GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'Fxb_Sample_Admin_Help' ) ) {

/**
 * Class - Fxb_Sample_Admin_Help
 *
 * @since 1.0.0
 */
class Fxb_Sample_Admin_Help {

	/**
	 * Constructor
	 *
	 * @since  1.0.0
	 * @access public
	 * @return void
	 */
	public function __construct() {
		add_action( 'current_screen', array( $this, 'add_help_tabs' ), 50 );
	} // END __construct()

	/**
	 * Adds help tabs to the plugin pages.
	 *
	 * @since  1.0.0
	 * @access public
	 */
	public function add_help_tabs() {
		$screen = get_current_screen();

		if ( ! in_array( $screen->id, fxb_sample_get_screen_ids() ) )
			return;

		$screen->add_help_tab( array(
			'id'      => 'fxb_sample_docs_tab',
			'title'   => __( 'Documentation', 'fxb-sample' ),
			'content' =>
				'<p>' . sprintf( __( 'Thank you for using <strong>%s</strong> :) Should you need help using or extending %s please read the documentation.', 'fxb-sample' ), Fxb_Sample()->name, Fxb_Sample()->name ) . '</p>' .

				'<p><a href="' . Fxb_Sample()->doc_url . '" class="button button-primary">' . sprintf( __( '%s Documentation', 'fxb-sample' ), Fxb_Sample()->name ) . '</a> <!--a href="#" class="button">' . __( 'Restart Tour', 'fxb-sample' ) . '</a--></p>'
		) );

		$screen->add_help_tab( array(
			'id'      => 'fxb_sample_support_tab',
			'title'   => __( 'Support', 'fxb-sample' ),
			'content' =>
				'<p>' . sprintf( __( 'After <a href="%s">reading the documentation</a>, for further assistance you can use the <a href="%s">community forum</a>.', 'fxb-sample' ), Fxb_Sample()->doc_url, Fxb_Sample()->wp_plugin_support_url, __( 'Company Name' , 'fxb-sample' ) ) . '</p>' .

				'<p>' . __( 'Before asking for help we recommend checking the status page to identify any problems with your configuration.', 'fxb-sample' ) . '</p>' .

				'<p><a href="' . admin_url( 'admin.php?page=' . FXB_SAMPLE_PAGE . '-status' ) . '" class="button button-primary">' . __( 'System Status', 'fxb-sample' ) . '</a> <a href="' . Fxb_Sample()->wp_plugin_support_url . '" class="button">' . __( 'Community Support', 'fxb-sample' ) . '</a>'
		) );

		$screen->add_help_tab( array(
			'id'      => 'fxb_sample_bugs_tab',
			'title'   => __( 'Found a bug?', 'fxb-sample' ),
			'content' =>
				'<p>' . sprintf( __( 'If you find a bug within <strong>%s</strong> you can create a ticket via <a href="%s">Github issues</a>. Ensure you read the <a href="%s">contribution guide</a> prior to submitting your report. Be as descriptive as possible and please include your <a href="%s">system status report</a>.', 'fxb-sample' ), Fxb_Sample()->name, FXB_SAMPLE_GITHUB_REPO_URI . 'issues?state=open', FXB_SAMPLE_GITHUB_REPO_URI . 'blob/master/CONTRIBUTING.md', admin_url( 'admin.php?page=' . FXB_SAMPLE_PAGE . '-status' ) ) . '</p>' .

				'<p><a href="' . FXB_SAMPLE_GITHUB_REPO_URI . 'issues?state=open" class="button button-primary">' . __( 'Report a bug', 'fxb-sample' ) . '</a> <a href="' . admin_url( 'admin.php?page=' . FXB_SAMPLE_PAGE . '-status' ) . '" class="button">' . __( 'System Status', 'fxb-sample' ) . '</a></p>'
		) );

		if ( !empty( Fxb_Sample()->web_url ) || !empty( Fxb_Sample()->wp_plugin_url ) || defined( FXB_SAMPLE_GITHUB_REPO_URI ) ) {
			$screen->set_help_sidebar(
				'<p><strong>' . __( 'For more information:', 'fxb-sample' ) . '</strong></p>' .
				'<p><a href="' . Fxb_Sample()->web_url . '" target="_blank">' . sprintf( __( 'About %s', 'fxb-sample' ), Fxb_Sample()->name ) . '</a></p>' .
				'<p><a href="' . Fxb_Sample()->wp_plugin_url . '" target="_blank">' . __( 'Project on WordPress.org', 'fxb-sample' ) . '</a></p>' .
				'<p><a href="' . FXB_SAMPLE_GITHUB_REPO_URI . '" target="_blank">' . __( 'Project on Github', 'fxb-sample' ) . '</a></p>'
			);
		}

	} // END add_help_tabs()

} // END Fxb_Sample_Admin_Help class.

} // END if class exists.

return new Fxb_Sample_Admin_Help();

?>
