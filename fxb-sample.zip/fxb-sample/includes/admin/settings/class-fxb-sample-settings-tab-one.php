<?php
/**
 * Plugin Name First Tab Settings
 *
 * @since    1.0.0
 * @author FX Bénard
 * @category Admin
 * @package  Plugin Name
 * @license  GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'Fxb_Sample_Settings_First_Tab' ) ) {

/**
 * Fxb_Sample_Settings_First_Tab
 */
class Fxb_Sample_Settings_First_Tab extends Fxb_Sample_Settings_Page {

	/**
	 * Constructor.
	 *
	 * @since  1.0.0
	 * @access public
	 */
	public function __construct() {
		$this->id    = 'tab_one';
		$this->label = __( 'First Tab', 'fxb-sample' );

		add_filter( 'fxb_sample_settings_submenu_array',           array( $this, 'add_menu_page' ),     20 );
		add_filter( 'fxb_sample_settings_tabs_array',              array( $this, 'add_settings_page' ), 20 );
		add_action( 'fxb_sample_settings_' . $this->id,            array( $this, 'output' ) );
		add_action( 'fxb_sample_settings_save_' . $this->id,       array( $this, 'save' ) );
		add_action( 'fxb_sample_settings_start',                   array( $this, 'settings_top' ) );
		add_action( 'fxb_sample_settings_start_tab_' . $this->id,  array( $this, 'settings_top_this_tab_only' ) );
		add_action( 'fxb_sample_settings_finish',                  array( $this, 'settings_bottom' ) );
		add_action( 'fxb_sample_settings_finish_tab_' . $this->id, array( $this, 'settings_bottom_this_tab_only' ) );
	} // END __construct()

	/**
	 * Save settings
	 *
	 * @since  1.0.0
	 * @access public
	 * @global $current_tab
	 */
	public function save() {
		global $current_tab;

		$settings = $this->get_settings();

		Fxb_Sample_Admin_Settings::save_fields( $settings, $current_tab );
	}

	/**
	 * Get settings array
	 *
	 * @since  1.0.0
	 * @access public
	 * @return array
	 */
	public function get_settings() {

		return apply_filters( 'fxb_sample_' . $this->id . '_settings', array(

			array(
				'title' 	=> __( 'Settings Title', 'fxb-sample' ),
				'type' 		=> 'title',
				'desc' 		=> '',
				'id' 		=> $this->id . '_options'
			),

			array(
				'title' 	=> __( 'Subscriber Access', 'fxb-sample' ),
				'desc' 		=> __( 'Prevent users from accessing WordPress admin.', 'fxb-sample' ),
				'id' 		=> 'fxb_sample_lock_down_admin',
				'default'	=> 'no',
				'type' 		=> 'checkbox',
			),

			array(
				'title' 	=> __( 'Secure Content', 'fxb-sample' ),
				'desc' 		=> __( 'Keep your site secure by forcing SSL (HTTPS) on site (an SSL Certificate is required).', 'fxb-sample' ),
				'id' 		=> 'fxb_sample_force_ssl',
				'default'	=> 'no',
				'type' 		=> 'checkbox'
			),

			array(
				'title' 	=> __( 'Select Country', 'fxb-sample' ),
				'desc' 		=> __( 'This gives you a list of countries. ', 'fxb-sample' ),
				'id' 		=> 'fxb_sample_country_list',
				'css' 		=> 'min-width:350px;',
				'default'	=> 'GB',
				'type' 		=> 'single_select_country',
				'desc_tip'	=> true,
			),

			array(
				'title' 	=> __( 'Multi Select Countries', 'fxb-sample' ),
				'desc' 		=> '',
				'id' 		=> 'fxb_sample_multi_countries',
				'css' 		=> 'min-width: 350px;',
				'default'	=> '',
				'type' 		=> 'multi_select_countries'
			),

			array(
				'title' 	=> __( 'Example Page', 'fxb-sample' ),
				'desc' 		=> __( 'You can set pages that the plugin requires by having them installed and selected automatically when the plugin is installed.', 'fxb-sample' ),
				'id' 		=> 'fxb_sample_example_page_id',
				'type' 		=> 'single_select_page',
				'default'	=> '',
				'class'		=> 'chosen_select_nostd',
				'css' 		=> 'min-width:300px;',
				'desc_tip'	=> true,
			),

			array(
				'title' 	=> __( 'Shortcode Example Page', 'fxb-sample' ),
				'desc' 		=> __( 'This page has a shortcode applied when created by the plugin.', 'fxb-sample' ),
				'id' 		=> 'fxb_sample_shortcode_page_id',
				'type' 		=> 'single_select_page',
				'default'	=> '',
				'class'		=> 'chosen_select_nostd',
				'css' 		=> 'min-width:300px;',
				'desc_tip'	=> true,
			),

			array(
				'title' 	=> __( 'Single Checkbox', 'fxb-sample' ),
				'desc' 		=> __( 'Can come in handy to display more options.', 'fxb-sample' ),
				'id' 		=> 'fxb_sample_checkbox',
				'default'	=> 'no',
				'type' 		=> 'checkbox'
			),

			array(
				'title' 	=> __( 'Single Input (Text) ', 'fxb-sample' ),
				'desc' 		=> '',
				'id' 		=> 'fxb_sample_input_text',
				'default'	=> __( 'This admin setting can be hidden via the checkbox above.', 'fxb-sample' ),
				'type' 		=> 'text',
				'css' 		=> 'min-width:300px;',
				'autoload' 	=> false
			),

			array(
				'title' 	=> __( 'Single Textarea ', 'fxb-sample' ),
				'desc' 		=> '',
				'id' 		=> 'fxb_sample_input_textarea',
				'default'	=> __( 'You can allow the user to use this field to enter their own CSS or HTML code.', 'fxb-sample' ),
				'type' 		=> 'textarea',
				'css' 		=> 'min-width:300px;',
				'autoload' 	=> false
			),

			array( 'type' => 'sectionend', 'id' => $this->id . '_options'),

		)); // End general settings
	}

}

} // end if class exists

return new Fxb_Sample_Settings_First_Tab();

?>
