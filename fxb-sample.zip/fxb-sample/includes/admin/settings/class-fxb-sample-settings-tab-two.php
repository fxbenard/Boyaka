<?php
/**
 * Plugin Name Second Tab Settings
 *
 * @since    1.0.0
 * @author FX Bénard
 * @category Admin
 * @package  Plugin Name
 * @license  GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! class_exists( 'Fxb_Sample_Settings_Second_Tab' ) ) {

/**
 * Fxb_Sample_Settings_Second_Tab
 */
class Fxb_Sample_Settings_Second_Tab extends Fxb_Sample_Settings_Page {

	/**
	 * Constructor.
	 *
	 * @since  1.0.0
	 * @access public
	 */
	public function __construct() {
		$this->id    = 'tab_two';
		$this->label = __( 'Second Tab', 'fxb-sample' );

		add_filter( 'fxb_sample_settings_submenu_array',           array( $this, 'add_menu_page' ),     20 );
		add_filter( 'fxb_sample_settings_tabs_array',              array( $this, 'add_settings_page' ), 20 );
		add_action( 'fxb_sample_settings_' . $this->id,            array( $this, 'output' ) );
		add_action( 'fxb_sample_settings_save_' . $this->id,       array( $this, 'save' ) );
		add_action( 'fxb_sample_sections_' . $this->id,            array( $this, 'output_sections' ) );
		add_action( 'fxb_sample_settings_start',                   array( $this, 'settings_top' ) );
		add_action( 'fxb_sample_settings_start_tab_' . $this->id,  array( $this, 'settings_top_this_tab_only' ) );
		add_action( 'fxb_sample_settings_finish',                  array( $this, 'settings_bottom' ) );
		add_action( 'fxb_sample_settings_finish_tab_' . $this->id, array( $this, 'settings_bottom_this_tab_only' ) );
	} // END __construct()

	/**
	 * Get sections
	 *
	 * @since  1.0.0
	 * @access public
	 * @return array
	 */
	public function get_sections() {
		$sections = array(
			''    => __( 'Section One', 'fxb-sample' ),
			'two' => __( 'Section Two', 'fxb-sample' )
		);

		return $sections;
	}

	/**
	 * Output the settings
	 *
	 * @since  1.0.0
	 * @access public
	 * @global $current_section
	 */
	public function output() {
		global $current_section;

		$settings = $this->get_settings( $current_section );

 		Fxb_Sample_Admin_Settings::output_fields( $settings );
	}

	/**
	 * Save settings
	 *
	 * @since  1.0.0
	 * @access public
	 * @global $current_tab
	 * @global $current_section
	 */
	public function save() {
		global $current_tab, $current_section;

		$settings = $this->get_settings( $current_section );

		Fxb_Sample_Admin_Settings::save_fields( $settings, $current_tab, $current_section );
	}

	/**
	 * Get settings array
	 *
	 * @since  1.0.0
	 * @access public
	 * @param  $current_section
	 * @return array
	 */
	public function get_settings( $current_section = '' ) {

		if ( $current_section == 'two' ) {

			return apply_filters( 'fxb_sample_second_tab_settings_section_' . $current_section, array(

				array(
					'title' => __( 'Section Two Options', 'fxb-sample' ),
					'type'  => 'title',
					'desc'  => '',
					'id'    => 'section_two_options'
				),

				array(
					'title'    => __( 'Select Page', 'fxb-sample' ),
					'desc'     => '<br/>' . sprintf( __( 'You can set a description here also.', 'fxb-sample' ), admin_url( 'options-permalink.php' ) ),
					'id'       => 'fxb_sample_select_single_page_id',
					'type'     => 'single_select_page',
					'default'  => '',
					'class'    => 'chosen_select_nostd',
					'css'      => 'min-width:300px;',
					'desc_tip' => __( 'You can select or search for a page.', 'fxb-sample' ),
				),

				array(
					'title'    => __( 'Select', 'fxb-sample' ),
					'desc'     => __( 'This example shows you options from an array().', 'fxb-sample' ),
					'id'       => 'fxb_sample_select_array',
					'class'    => 'chosen_select',
					'css'      => 'min-width:300px;',
					'default'  => '',
					'type'     => 'select',
					'options'  => array(
						'yes'    => __( 'Yes', 'fxb-sample' ),
						'no'     => __( 'No', 'fxb-sample' ),
					),
					'desc_tip' =>  true,
				),

				array(
					'title'    => __( 'MultiSelect', 'fxb-sample' ),
					'desc'     => __( 'This example shows you the ability to select multi options from an array().', 'fxb-sample' ),
					'id'       => 'fxb_sample_multiselect_array',
					'class'    => 'chosen_select',
					'css'      => 'min-width:300px;',
					'default'  => '',
					'type'     => 'multiselect',
					'options'  => array(
						'yes'    => __( 'Yes', 'fxb-sample' ),
						'no'     => __( 'No', 'fxb-sample' ),
					),
					'desc_tip' =>  true,
				),

				array(
					'title'   => __( 'Checkbox', 'fxb-sample' ),
					'desc'    => __( 'Checkbox option', 'fxb-sample' ),
					'id'      => 'fxb_sample_checkbox',
					'default' => 'no',
					'type'    => 'checkbox'
				),

				array(
					'title'    => __( 'Radio', 'fxb-sample' ),
					'desc'     => __( 'Radio option', 'fxb-sample' ),
					'desc_tip' => true,
					'id'       => 'fxb_sample_radio',
					'default'  => '',
					'type'     => 'radio',
					'options'  => array(
 						'yes'    => __( 'Yes', 'fxb-sample' ),
						'no'     => __( 'No', 'fxb-sample' ),
					),
				),

				array(
					'title'             => __( 'Number', 'fxb-sample' ),
					'desc'              => __( 'Use this field for numbered options.', 'fxb-sample' ),
					'id'                => 'fxb_sample_number_option',
					'type'              => 'number',
					'custom_attributes' => array(
						'min'             => 0,
						'step'            => 1
					),
					'css'               => 'width:50px;',
					'default'           => '05',
					'autoload'          => false
				),

				array(
					'title'    => __( 'Color', 'fxb-sample' ),
					'desc'     => __( 'Use this field for color picking.', 'fxb-sample' ),
					'id'       => 'fxb_sample_color_option',
					'type'     => 'color',
					'css'      => 'width:70px;',
					'default'  => '#ffffff',
					'autoload' => false
				),

				array(
					'title'         => __( 'Group Checkboxes', 'fxb-sample' ),
					'desc'          => __( 'Checkbox One', 'fxb-sample' ),
					'id'            => 'fxb_sample_group_checkbox_option_one',
					'default'       => 'yes',
					'type'          => 'checkbox',
					'checkboxgroup' => 'start',
					'autoload'      => false
				),

				array(
					'desc'          => __( 'Checkbox Two', 'fxb-sample' ),
					'id'            => 'fxb_sample_group_checkbox_option_two',
					'default'       => 'yes',
					'type'          => 'checkbox',
					'checkboxgroup' => 'end',
					'autoload'      => false
				),

				array(
					'title'    => __( 'Email', 'fxb-sample' ),
					'desc'     => 'Use this field option to be used for entering an email address only. (HTML 5 Field)',
					'id'       => 'fxb_sample_email_option',
					'type'     => 'email',
					'default'  => get_option( 'admin_email' ),
					'autoload' => false
				),

				array(
					'title'    => __( 'Password', 'fxb-sample' ),
					'desc'     => 'Use this field option to be used for entering a password.',
					'id'       => 'fxb_sample_password_option',
					'type'     => 'password',
					'default'  => '',
					'autoload' => false
				),

				array(
					'title'    => __( 'Image Size', 'fxb-sample' ),
					'desc'     => __( 'Use this field option to save multiple settings for an image size', 'fxb-sample' ),
					'id'       => 'fxb_sample_image_size_option',
					'css'      => '',
					'type'     => 'image_width',
					'default'  => array(
						'width'  => '150',
						'height' => '150',
						'crop'   => false
					),
					'desc_tip' => true,
				),

				array( 'type' => 'sectionend', 'id' => 'section_two_options'),

			));

		} else {

			return apply_filters( 'fxb_sample_second_tab_settings', array(

				array(
					'title' => __( 'Section One Options', 'fxb-sample' ),
					'type'  => 'title',
					'desc'  => '',
					'id'    => 'section_one_options'
				),

				array(
					'title'    => __( 'Select Page', 'fxb-sample' ),
					'desc'     => '<br/>' . sprintf( __( 'You can set a description here also.', 'fxb-sample' ), admin_url( 'options-permalink.php' ) ),
					'id'       => 'fxb_sample_select_single_page_id',
					'type'     => 'single_select_page',
					'default'  => '',
					'class'    => 'chosen_select_nostd',
					'css'      => 'min-width:300px;',
					'desc_tip' => __( 'You can select or search for a page.', 'fxb-sample' ),
				),

				array(
					'title'    => __( 'Select', 'fxb-sample' ),
					'desc'     => __( 'This example shows you options from an array().', 'fxb-sample' ),
					'id'       => 'fxb_sample_select_array',
					'class'    => 'chosen_select',
					'css'      => 'min-width:300px;',
					'default'  => '',
					'type'     => 'select',
					'options'  => array(
						'yes'    => __( 'Yes', 'fxb-sample' ),
						'no'     => __( 'No', 'fxb-sample' ),
					),
					'desc_tip' =>  true,
				),

				array(
					'title'    => __( 'MultiSelect', 'fxb-sample' ),
					'desc'     => __( 'This example shows you the ability to select multi options from an array().', 'fxb-sample' ),
					'id'       => 'fxb_sample_multiselect_array',
					'class'    => 'chosen_select',
					'css'      => 'min-width:300px;',
					'default'  => '',
					'type'     => 'multiselect',
					'options'  => array(
						'yes'    => __( 'Yes', 'fxb-sample' ),
						'no'     => __( 'No', 'fxb-sample' ),
					),
					'desc_tip' =>  true,
				),

				array(
					'title'   => __( 'Checkbox', 'fxb-sample' ),
					'desc'    => __( 'Checkbox option', 'fxb-sample' ),
					'id'      => 'fxb_sample_checkbox',
					'default' => 'no',
					'type'    => 'checkbox'
				),

				array(
					'title' 	=> __( 'Radio', 'fxb-sample' ),
					'desc' 		=> __( 'Radio option', 'fxb-sample' ),
					'desc_tip' 	=> true,
					'id' 		=> 'fxb_sample_radio',
					'default'	=> '',
					'type' 		=> 'radio',
					'options' => array(
									'yes' => __( 'Yes', 'fxb-sample' ),
									'no' => __( 'No', 'fxb-sample' ),
					),
				),

				array(
					'title' 	=> __( 'Number', 'fxb-sample' ),
					'desc' 		=> __( 'Use this field for numbered options.', 'fxb-sample' ),
					'id' 		=> 'fxb_sample_number_option',
					'type' 		=> 'number',
					'custom_attributes' => array(
						'min' 	=> 0,
						'step' 	=> 1
					),
					'css' 		=> 'width:50px;',
					'default'	=> '05',
					'autoload' 	=> false
				),

				array(
					'title' 	=> __( 'Color', 'fxb-sample' ),
					'desc' 		=> __( 'Use this field for color picking.', 'fxb-sample' ),
					'id' 		=> 'fxb_sample_color_option',
					'type' 		=> 'color',
					'css' 		=> 'width:70px;',
					'default'	=> '#ffffff',
					'autoload' 	=> false
				),

				array(
					'title' 		=> __( 'Group Checkboxes', 'fxb-sample' ),
					'desc' 			=> __( 'Checkbox One', 'fxb-sample' ),
					'id' 			=> 'fxb_sample_group_checkbox_option_one',
					'default'		=> 'yes',
					'type' 			=> 'checkbox',
					'checkboxgroup' => 'start',
					'autoload' 		=> false
				),

				array(
					'desc' 			=> __( 'Checkbox Two', 'fxb-sample' ),
					'id' 			=> 'fxb_sample_group_checkbox_option_two',
					'default'		=> 'yes',
					'type' 			=> 'checkbox',
					'checkboxgroup' => 'end',
					'autoload' 		=> false
				),

				array(
					'title' 		=> __( 'Email', 'fxb-sample' ),
					'desc' 			=> 'Use this field option to be used for entering an email address only. (HTML 5 Field)',
					'id' 			=> 'fxb_sample_email_option',
					'type' 			=> 'email',
					'default'		=> get_option( 'admin_email' ),
					'autoload' 		=> false
				),

				array(
					'title' 		=> __( 'Password', 'fxb-sample' ),
					'desc' 			=> 'Use this field option to be used for entering a password.',
					'id' 			=> 'fxb_sample_password_option',
					'type' 			=> 'password',
					'default'		=> '',
					'autoload' 		=> false
				),

				array(
					'title' 		=> __( 'Image Size', 'fxb-sample' ),
					'desc' 			=> __( 'Use this field option to save multiple settings for an image size', 'fxb-sample' ),
					'id' 			=> 'fxb_sample_image_size_option',
					'css' 			=> '',
					'type' 			=> 'image_width',
					'default'		=> array(
						'width' 		=> '150',
						'height'		=> '150',
						'crop'			=> false
					),
					'desc_tip' 		=> true,
				),

				array( 'type' => 'sectionend', 'id' => 'section_one_options'),

			));
		}
	}
}

} // end if class exists

return new Fxb_Sample_Settings_Second_Tab();

?>
