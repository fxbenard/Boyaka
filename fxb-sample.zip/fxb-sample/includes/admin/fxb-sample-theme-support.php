<?php
$themes_supported = array(
	'twentyfifteen',
	'twentyfourteen',
	'twentythirteen',
	'twentytwelve',
	'twentyeleven',
	'twentyten',
);
?>
