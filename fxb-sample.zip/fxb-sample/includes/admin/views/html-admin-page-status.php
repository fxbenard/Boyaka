<?php
/**
 * Admin View: Page - Status
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$current_tab = ! empty( $_REQUEST['tab'] ) ? sanitize_title( $_REQUEST['tab'] ) : 'status';
?>
<div class="wrap fxb-sample fxb-sample-status">
	<h2 class="nav-tab-wrapper">
	<?php echo Fxb_Sample()->name; ?>
	<?php
		$tabs = apply_filters( 'fxb_sample_system_tools_tabs', array(
			'status' => __( 'System Status', 'fxb-sample' ),
			'tools'  => __( 'Tools', 'fxb-sample' ),
			//'import'  => __( 'Import', 'fxb-sample' ),
			//'export'  => __( 'Export', 'fxb-sample' ),
		) );
		foreach ( $tabs as $name => $label ) {
			echo '<a href="' . admin_url( 'admin.php?page=' . FXB_SAMPLE_PAGE . '-status&tab=' . $name ) . '" class="nav-tab ';
			if ( $current_tab == $name ) echo 'nav-tab-active';
			echo '">' . $label . '</a>';
		}
	?>
	</h2><br/>
	<?php
		switch ( $current_tab ) {
			case "import" :
				Fxb_Sample_Admin_Status::status_port( 'import' );
				break;
			case "export" :
				Fxb_Sample_Admin_Status::status_port( 'export' );
				break;
			case "tools" :
				Fxb_Sample_Admin_Status::status_tools();
				break;
			default :
				Fxb_Sample_Admin_Status::status_report();
				break;
		}
	?>
</div>
