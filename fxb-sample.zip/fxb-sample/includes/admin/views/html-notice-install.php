<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<div id="message" class="updated fxb-sample-message">
	<p><?php echo sprintf( __( '<strong>Welcome to %s</strong> &#8211; You\'re almost ready to start using this plugin :)', 'fxb-sample' ), Fxb_Sample()->name ); ?></p>
	<p class="submit"><a href="<?php echo add_query_arg( 'install_fxb_sample_pages', 'true', admin_url( 'admin.php?page=' . FXB_SAMPLE_PAGE . '-settings' ) ); ?>" class="button-primary"><?php echo sprintf( __( 'Install %s Pages', 'fxb-sample' ), Fxb_Sample()->name ); ?></a> <a class="skip button-primary" href="<?php echo add_query_arg( 'skip_install_fxb_sample_pages', 'true', admin_url( 'admin.php?page=' . FXB_SAMPLE_PAGE . '-settings' ) ); ?>"><?php _e( 'Skip setup', 'fxb-sample' ); ?></a></p>
</div>
