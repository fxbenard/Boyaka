<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<div id="message" class="updated fxb-sample-message">
	<p><?php _e( sprintf( '<strong>Your theme does not declare %s support</strong> &#8211; if you encounter layout issues please read our integration guide or choose a theme that is compatiable with %s.', Fxb_Sample()->name, Fxb_Sample()->name ), 'fxb-sample' ); ?></p>
	<p class="submit"><a href="<?php echo esc_url( apply_filters( 'fxb_sample_theme_docs_url', Fxb_Sample()->doc_url . 'theme-compatibility-intergration/', 'theme-compatibility' ) ); ?>" class="button-primary"><?php _e( 'Theme Integration Guide', 'fxb-sample' ); ?></a> <a class="skip button-primary" href="<?php echo esc_url( add_query_arg( 'hide_fxb_sample_theme_support_check', 'true' ) ); ?>"><?php _e( 'Hide this notice', 'fxb-sample' ); ?></a></p>
</div>