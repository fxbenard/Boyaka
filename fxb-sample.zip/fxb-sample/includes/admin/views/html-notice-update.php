<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<div id="message" class="updated fxb-sample-message">
	<p><?php echo sprintf( __( '<strong>%s Data Update Required</strong> &#8211; We just need to update your install to the latest version', 'fxb-sample' ), Fxb_Sample()->name ); ?></p>
	<p class="submit"><a href="<?php echo add_query_arg( 'do_update_fxb_sample', 'true', admin_url( 'admin.php?page=' . FXB_SAMPLE_PAGE . '-settings' ) ); ?>" class="fxb-sample-update-now button-primary"><?php _e( 'Run the updater', 'fxb-sample' ); ?></a></p>
</div>
<script type="text/javascript">
	jQuery('.fxb-sample-update-now').click('click', function(){
		var answer = confirm( '<?php _e( 'It is strongly recommended that you backup your database before proceeding. Are you sure you wish to run the updater now?', 'fxb-sample' ); ?>' );
		return answer;
	});
</script>
