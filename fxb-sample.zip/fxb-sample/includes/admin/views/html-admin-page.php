<div class="wrap fxb-sample">
	<h2>
		<?php echo Fxb_Sample()->name; ?>
		<?php
		/**
		 * These header links do not have to be external.
		 * You may change the links to an internal link connected with the plugin.
		 */
		$links = apply_filters( 'fxb_sample_admin_header_links', array(
			Fxb_Sample()->web_url . '?utm_source=wpadmin&utm_campaign=header' => __( 'Website', 'fxb-sample' ),
			Fxb_Sample()->doc_url . '?utm_source=wpadmin&utm_campaign=header' => __( 'Documentation', 'fxb-sample' ),
		) );

		$text = '';

		foreach( $links as $key => $value ) {
			$text .= '<a class="add-new-h2" href="' . $key . '">' . $value . '</a>';
		}

		echo $text;
		?>
	</h2>

	<ul class="subsubsub">
		<?php
			$links = apply_filters( 'fxb_sample_section_links', array(
				''      => __( 'Default', 'fxb-sample' ),
				'two'   => __( 'Section Two', 'fxb-sample' ),
				'three' => __( 'Section Three', 'fxb-sample' ),
			) );

			$i = 0;

			foreach ( $links as $link => $name ) {
				$i ++;
				?><li><a class="<?php if ( $view == $link ) { echo 'current'; } ?>" href="<?php echo admin_url( 'admin.php?page=' . FXB_SAMPLE_PAGE . '&view=' . esc_attr( $link ) ); ?>"><?php echo $name; ?></a><?php if ( $i != sizeof( $links ) ) { echo '|'; } ?></li><?php
			}
		?>
	</ul>
	<br class="clear" />

	<?php do_action('fxb_sample_page_header'); ?>

	<?php do_action('fxb_sample_page_' . $view . '_header'); ?>

	<?php
	/**
	 * The paragraphs below were added just as an example and to explain what this page can do.
	 * You may remove it but leave the hooks in place if you still want to use them.
	 */
	//if ( empty($view) ) $view = __('default', 'fxb_sample'); echo '<h3>' . __( 'You are viewing section:&nbsp;', 'fxb_sample' )  . '<em>' . $view . '</em></h3>';
	?>

	<p class="about-description"><?php _e( 'You can use this page to place the main back feature of your plugin. Place links at the end of your header and set the page into sections.', 'fxb-sample' ); ?></p>
	<p><?php _e( 'These sections can then display different content based on the section the user is viewing.', 'fxb-sample' ); ?></p>
	<p><?php _e( 'There are many actions and filters in place to allow you to add and display anything you need.', 'fxb-sample' ); ?></p>

	<?php echo $page_content; ?>

	<?php do_action('fxb_sample_page_' . $view . '_footer'); ?>

	<?php do_action('fxb_sample_page_footer'); ?>

</div>
