<?php
/**
 * Plugin Name Widgets
 *
 * @since    1.0.0
 * @author FX Bénard
 * @category Core
 * @package  Plugin Name/Functions
 * @license  GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>
