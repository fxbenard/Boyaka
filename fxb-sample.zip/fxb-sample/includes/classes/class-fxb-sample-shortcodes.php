<?php
/**
 * Plugin Name Shortcodes.
 *
 * @since    1.0.0
 * @author FX Bénard
 * @category Class
 * @package  Plugin Name/Classes
 * @license  GPL-2.0+
 */
class Fxb_Sample_Shortcodes {

	/**
	 * Initiate Shortcodes
	 *

	 * @since  1.0.0
	 * @access public static
	 */
	public static function init() {
		$shortcodes = array(
			'sample' => __CLASS__ . '::sample',
		);

		foreach ( $shortcodes as $shortcode => $function ) {
			add_shortcode( apply_filters( "fxb_sample_{$shortcode}_shortcode_tag", $shortcode ), $function );
		}
	} // END init()

	/**
	 * Shortcode Wrapper
	 *
	 * @since  1.0.0
	 * @access public
	 * @param  mixed $function
	 * @param  array $atts (default: array())
	 * @return string
	 */
	public function shortcode_wrapper(
		$function, $atts = array(), $wrapper = array( 'class' => 'fxb-sample', 'before' => null, 'after' => null ) ){
		ob_start();

		$before = empty( $wrapper['before'] ) ? '<div class="' . $wrapper['class'] . '">' : $wrapper['before'];
		$after  = empty( $wrapper['after'] ) ? '</div>' : $wrapper['after'];

		echo $before;
		call_user_func( $function, $atts );
		echo $after;

		return ob_get_clean();
	}

	/**
	 * Sample shortcode.
	 *
	 * @since  1.0.0
	 * @access public
	 * @param  mixed $atts
	 * @return string
	 */
	public static function sample( $atts ) {
		return $this->shortcode_wrapper( array( 'Fxb_Sample_Shortcode_Sample', 'output' ), $atts );
	} // END sample()

} // END Fxb_Sample_Shortcodes class
?>
